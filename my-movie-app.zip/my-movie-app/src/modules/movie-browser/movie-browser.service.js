import {MOVIE_DB_API_KEY} from '../../api-keys';
const MOVIE_DB_BASE_URL = 'https://api.themoviedb.org/3';

const createUrl = (relativeUrl, queryParams) => {
  let baseUrl = `${MOVIE_DB_BASE_URL}${relativeUrl}?api_key=${MOVIE_DB_API_KEY}`;
  if (queryParams) {
    Object.keys(queryParams)
      .forEach(paramName => baseUrl += `&${paramName}=${queryParams[paramName]}`);
  }
  return baseUrl;
}

export const getGenres = async () => {
  const fullUrl = createUrl('/genre/movie/list');
  return fetch(fullUrl);
}

export const getMoviesByGenre = async ({with_genres}) => {
  const fullUrl = createUrl('/discover/movie', {
    with_genres
  });
  return fetch(fullUrl); 
}


export const getMovieDetails = async ({movieId}) => {
  const fullUrl = createUrl(`/movie/${movieId}`);
  return fetch(fullUrl);
}
