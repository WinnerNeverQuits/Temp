import {createAsyncActionCreator} from '../common/redux.helpers';
import * as movieService from './movie-browser.service';

export const keys = {
  'GET_GENERES': 'GET_GENERES',
  'GET_MOVIES_BY_GENRE': 'GET_MOVIES_BY_GENRE',
  'GET_MOVIE_DETAILS': 'GET_MOVIE_DETAILS',
};

export const getGenres = () => createAsyncActionCreator(keys.GET_GENERES, movieService.getGenres);

export const getMoviesByGenre = (with_genres) => createAsyncActionCreator(
  // actionType
  keys.GET_MOVIES_BY_GENRE,
  // requestFn
  movieService.getMoviesByGenre, 
  // requestParams
  {with_genres}
);

export const getMovieDetails = (movieId) => createAsyncActionCreator(
  keys.GET_MOVIE_DETAILS,
  movieService.getMovieDetails, 
  {movieId}
);
