import {combineReducers} from 'redux';
import { createReducer, createAsyncReducer } from '../common/redux.helpers';
import { keys as movieActionKeys } from './movie-browser.actions';
import movieModalReducer from './movie-modal/movie-modal.reducer';

const moviesSuccessReducer = (state, action) => {
  return {
    ...state,
    isLoading: false,
    response: {
      ...action.response,
      results: [
        ...action.response.results
      ]
    }
  };
}

const movieBrowserReducer = combineReducers({
  movieModal: movieModalReducer,  
  genres: createAsyncReducer(movieActionKeys.GET_GENERES, {
    [`${movieActionKeys.GET_GENERES}_SUCCESS`]: moviesSuccessReducer
  }),
  moviesByGenre: createAsyncReducer(movieActionKeys.GET_MOVIES_BY_GENRE, {
    [`${movieActionKeys.GET_MOVIES_BY_GENRE}_SUCCESS`]: moviesSuccessReducer
  }),
  movieDetails: createAsyncReducer(movieActionKeys.GET_MOVIE_DETAILS),
});

export default movieBrowserReducer;
