import React from 'react';
import { connect } from 'react-redux';
import { Grid, Row, Col } from 'react-bootstrap';
import { AppBar, TextField, RaisedButton } from 'material-ui';
import * as movieActions from './movie-browser.actions';
import * as movieHelpers from './movie-browser.helpers';
import MovieList from './movie-list/movie-list.component';
import MovieModal from './movie-modal/movie-modal.container';

class MovieBrowser extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.handleChangeGenre = this.handleChangeGenre.bind(this);
  }

  handleChangeGenre(event) {
    if(event.target.value)
    this.props.getMoviesByGenre(event.target.value);
  }
  

  render() {
    const { moviesByGenre } = this.props;
    const movies = movieHelpers.getMoviesList(moviesByGenre.response);

    return (
      <div>
        <AppBar title='Movie Browser'>
        </AppBar>
        <Grid>
          <Row>
            <label>Select a Genre:
              <select onChange={this.handleChangeGenre}>
                <option value=""></option>
                <option value="28">Action</option>
                <option value="35">Comedy</option>
              </select>
            </label>
          </Row>
          <Row>
            <MovieList movies={movies} isLoading={moviesByGenre.isLoading} />
          </Row>
        </Grid>
        <MovieModal />
      </div>
    );
  }
}

export default connect(  
  (state) => ({
    moviesByGenre: state.movieBrowser.moviesByGenre,
    genres: state.movieBrowser.genres
  }),  
  { ...movieActions }
)(MovieBrowser);
