import React from 'react';
import {connect} from 'react-redux';
import {Grid, Row, Col} from 'react-bootstrap';
import {AppBar, TextField, RaisedButton} from 'material-ui';
import * as movieActions from './movie-browser.actions';
import * as movieHelpers from './movie-browser.helpers';
import MovieList from './movie-list/movie-list.component';
import * as scrollHelpers from '../common/scroll.helpers';
import MovieModal from './movie-modal/movie-modal.container';

class MovieBrowser extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
   
    };   
    
    this.handleSearch = this.handleSearch.bind(this);
  }

  handleSearch(event) {
    this.props.searchMovies(event.target.value);
  }

  componentDidMount() {    
    this.props.getGenres();
    this.props.getTopMovies();
  }

  
  render() {    
    const {genres} = this.props;
    // console.log(genres);
    const genresList = movieHelpers.getGenresList(genres.response);
    
    const {topMovies} = this.props;
    const movies = movieHelpers.getMoviesList(topMovies.response);

    // const options = genres
    // ? genres.map(genre => (
    //   <option key={genre}>{genre}</option>
    //   ))
    //   : null;

    return (
      <div>
        <AppBar title='Movie Browser' />
        <Grid>
          <Row>
          <label>
              Genre:
              <select onChange={this.handleSearch}>
              {/* {options} */}
              </select>
            </label>
          </Row>
          <Row>
          <MovieList movies={movies} isLoading={topMovies.isLoading} />
          </Row>
        </Grid>
        <MovieModal />
      </div>
    );
  }
}

export default connect(  
  (state) => ({    
    genres: state.movieBrowser.genres,
    topMovies: state.movieBrowser.topMovies
  }),  
  { ...movieActions }
)(MovieBrowser);
