const config = require("@discovery-dni/cd-tv-internal.rollup-config");

module.exports = config({
  name: "sonic",
  global: "Sonic"
});
