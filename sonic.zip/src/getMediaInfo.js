import { __, pathOr } from "ramda";
import { catchError, map } from "rxjs/operators";
import { fetch } from "./fetch";
import { handleGenericErrors } from "./handleGenericErrors";

const mapVideoInfo = type => json => {
  let { data } = json;

  if (Array.isArray(data)) {
    [data] = data;
  }

  const p = pathOr("", __, data);
  const analyticsId = p(["attributes", "identifiers", "analyticsId"]);
  let mms = p(["attributes", "identifiers", "originalMediaId"]);

  if (analyticsId) {
    mms = analyticsId;
  } else if (type === "channel" || p(["attributes", "videoType"]) === "LIVE") {
    mms = p(["attributes", "identifiers", "alternateId"]);
  }

  return {
    isChannel: type === "channel",
    id: p(["id"]),
    title: p(["attributes", "name"]),
    channel: {
      analytics: analyticsId
    },
    video: {
      airDate: p(["attributes", "airData"]),
      showId:
        type === "channel" ? "" : p(["relationships", "show", "data", "id"]),
      season: p(["attributes", "seasonNumber"]),
      episode: p(["attributes", "episodeNumber"]),
      duration: p(["attributes", "videoDuration"]),
      description: p(["attributes", "description"])
    },
    startAt: 0,
    isLive: type === "channel" || p(["attributes", "videoType"]) === "LIVE",
    identifiers: {
      freewheel: p(["attributes", "identifiers", "freewheel"]),
      analytics: analyticsId,
      alternative: p(["attributes", "identifiers", "alternateId"]),
      original: p(["attributes", "identifiers", "originalMediaId"]),
      mms
    }
  };
};

export const getMediaInfo = (id, type) =>
  fetch(`/content/${type}s/${id}`, true).pipe(
    map(mapVideoInfo(type)),
    catchError(handleGenericErrors)
  );
