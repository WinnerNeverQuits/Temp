import { __, pathOr } from "ramda";
import { catchError, map } from "rxjs/operators";
import { fetch } from "./fetch";
import { handleGenericErrors } from "./handleGenericErrors";

const mapPlaybackInfo = type => json => {
  const p = pathOr("", __, json);

  return {
    src: {
      dash: p(["data", "attributes", "streaming", "dash", "url"]),
      hls: p(["data", "attributes", "streaming", "hls", "url"])
    },
    isLive: type === "channel",
    clearkey: {
      enabled: p(["data", "attributes", "protection", "clearkeyEnabled"]),
      licenseUrl: p([
        "data",
        "attributes",
        "protection",
        "schemes",
        "clearkey",
        "licenseUrl"
      ])
    },
    DRM: {
      enabled: p(["data", "attributes", "protection", "drmEnabled"]),
      widevine: p([
        "data",
        "attributes",
        "protection",
        "schemes",
        "widevine",
        "licenseUrl"
      ]),
      playready: p([
        "data",
        "attributes",
        "protection",
        "schemes",
        "playready",
        "licenseUrl"
      ]),
      fairplay: p([
        "data",
        "attributes",
        "protection",
        "schemes",
        "fairplay",
        "licenseUrl"
      ]),
      token: p(["data", "attributes", "protection", "drmToken"])
    },
    sonicReporting: {
      interval: p(["data", "attributes", "reportProgressInterval"])
    },
    videoAboutToEnd:
      type === "channel"
        ? 0
        : p(["data", "attributes", "markers", "videoAboutToEnd"])
  };
};

export const getPlaybackInfo = (id, type) =>
  fetch(`/playback/${type}PlaybackInfo/${id}?usePreAuth=true`, true).pipe(
    map(mapPlaybackInfo(type)),
    catchError(handleGenericErrors)
  );
