import Cookie from "js-cookie";
import { catchError, map, tap, withLatestFrom } from "rxjs/operators";
import { fetch } from "./fetch";
import { sonicConfig, sonicConfig$ } from "./sonicConfig$";
import { handleGenericErrors } from "./handleGenericErrors";

export const logout = () =>
  fetch("/logout", true, {
    method: "post",
    headers: new Headers({ "content-type": "application/json" })
  }).pipe(
    withLatestFrom(sonicConfig$),
    map(([res, { baseURI, token }]) => {
      const logoutToken =
        res && res.data && res.data.attributes && res.data.attributes.token;

      if (logoutToken) {
        Cookie.set("token", logoutToken);

        return {
          baseURI,
          token: logoutToken
        };
      }
    }),
    tap(sonicConfig),
    catchError(handleGenericErrors)
  );
