import Cookie from "js-cookie";
import { path } from "ramda";
import { catchError, map, tap, withLatestFrom } from "rxjs/operators";
import { fetch } from "./fetch";
import { sonicConfig, sonicConfig$ } from "./sonicConfig$";
import { handleGenericErrors } from "./handleGenericErrors";

export const loginWithFacebook = accessToken =>
  fetch(`/login`, true, {
    method: "post",
    headers: new Headers({ "content-type": "application/json" }),
    body: JSON.stringify({ credentials: { accessToken } })
  }).pipe(
    withLatestFrom(sonicConfig$),
    map(([res, { baseURI }]) => {
      const token = path(["data", "attributes", "token"], res);

      if (token) {
        Cookie.set("token", token);

        return {
          baseURI,
          token: token
        };
      }
    }),
    tap(sonicConfig),
    catchError(handleGenericErrors)
  );
