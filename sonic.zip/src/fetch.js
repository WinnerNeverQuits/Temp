import { forkJoin, from, of } from "rxjs";
import { flatMap, map, withLatestFrom } from "rxjs/operators";
import { sonicConfig$ } from "./sonicConfig$";

import { version as coreVersion } from "../../../package.json";

const _fetch = (url, auth = true, options = {}) =>
  of({ url, options }).pipe(
    withLatestFrom(sonicConfig$),
    flatMap(
      ([{ url, options }, { baseURI, token, clientName, clientVersion }]) => {
        const opts = Object.assign({}, options);

        if (auth) {
          if (!opts.headers) {
            opts.headers = new Headers();
          }
          opts.headers.append("Authorization", `Bearer ${token}`);

          opts.headers.append(
            "X-disco-client",
            `TVSET:${coreVersion}:${clientName}:${clientVersion}`
          );
        }

        return from(fetch(`${baseURI}${url}`, opts)).pipe(
          flatMap(res => {
            const contentType = res.headers.get("content-type");

            if (
              contentType &&
              contentType.indexOf("application/json") !== -1 &&
              res.status !== 204
            ) {
              return forkJoin(of(res.status), res.json());
            }
            return forkJoin(of(res.status), res.text());
          }),
          map(([status, json]) => {
            if (status === 200 || status === 204) {
              return json;
            }

            const err = new Error();
            err.message = json.errors;

            throw err;
          })
        );
      }
    )
  );

export { _fetch as fetch };
