import { getCurrentUser } from "./getCurrentUser";

//todo  
describe('test getCurrentUser', () => {
    beforeEach(() => {
      fetch.resetMocks();
    });
  
    it('users url is hit once', () => {
      fetch.mockResponseOnce();
      
      const user = getCurrentUser();
        
      //assert on the arguments given to fetch
      // expect(fetch.mock.calls[0][0]).toEqual('/users/me');
  
      //assert on the times called
      // expect(fetch.mock.calls.length).toEqual(1);
    });
    
  })

  