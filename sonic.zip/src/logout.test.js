import { logout } from "./logout";


describe('logout test', () => {
  beforeEach(() => {
    fetch.resetMocks();
  });

  it('logout url is hit once', () => {
    fetch.mockResponseOnce();
    
    logout().subscribe();

    //assert on the arguments given to fetch
    expect(fetch.mock.calls[0][0]).toEqual('/logout');

    //assert on the times called
    expect(fetch.mock.calls.length).toEqual(1);
  });
  
})

