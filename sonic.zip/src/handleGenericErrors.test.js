import { handleGenericErrors } from "./handleGenericErrors";

test('handleGenericErrors', () => {
  const err = new Error();
  err.message = [];
  err.message[0] = {
    status: 'err-status',
    code: 'err-code',
    detail: 'err-detail'
  }
  console.log(handleGenericErrors(err));
  // expect(handleGenericErrors(err)).toThrowError();
});