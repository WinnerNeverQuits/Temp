import Cookie from "js-cookie";
import { catchError, map, tap, withLatestFrom } from "rxjs/operators";
import { fetch } from "./fetch";
import { sonicConfig, sonicConfig$ } from "./sonicConfig$";
import { handleGenericErrors } from "./handleGenericErrors";

export const login = (username, password) =>
  fetch(`/login`, true, {
    method: "post",
    headers: new Headers({ "content-type": "application/json" }),
    body: JSON.stringify({ credentials: { username, password } })
  }).pipe(
    withLatestFrom(sonicConfig$),
    map(([res, { baseURI, token }]) => {
      const loginToken =
        res && res.data && res.data.attributes && res.data.attributes.token;

      if (loginToken) {
        Cookie.set("token", loginToken);

        return {
          baseURI,
          token: loginToken
        };
      }
    }),
    tap(sonicConfig),
    catchError(handleGenericErrors)
  );
