import { catchError, map } from "rxjs/operators";
import { fetch } from "./fetch";
import { stringify } from "qs";
import { handleGenericErrors } from "./handleGenericErrors";

export const getCollections = (alias, params = {}) => {
  params.include = "default";

  const urlParams = stringify(params, { encodeValuesOnly: true });

  return fetch(`/cms/collections/${alias}?${urlParams}`).pipe(
    map(res => res),
    catchError(handleGenericErrors)
  );
};
