import { fetch } from "./fetch";

export const getRoute = route => fetch(`/cms/routes${route}?include=default`);
