import { catchError, map } from "rxjs/operators";
import { fetch } from "./fetch";
import { handleGenericErrors } from "./handleGenericErrors";

export const resetPassword = username =>
  fetch("/users/registration/resetPassword", true, {
    method: "post",
    headers: new Headers({ "content-type": "application/json" }),
    body: JSON.stringify({ username })
  }).pipe(
    map(() => null),
    catchError(handleGenericErrors)
  );
