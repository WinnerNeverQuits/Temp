import { sonicConfig$ } from "./sonicConfig$";

test('sonicConfig$ emits right initial config properties', done => {
  let configExpected = { baseURI: '', token: '', clientName: '', clientVersion: '' };  
  sonicConfig$.subscribe( configEmitted => {
    expect(configEmitted).toStrictEqual(configExpected);
    done();
  });
});

test('sonicConfig initialisation', done => {
  let configInitialised = { baseURI: 'https://global-test.disco-api.com/realms', token: 'test', clientName: 'eurosport', clientVersion: '1.0.0' };  
  sonicConfig$.next(configInitialised);
  sonicConfig$.subscribe( configEmitted => {
    expect(configEmitted).toStrictEqual(configInitialised);
    done();
  });
});