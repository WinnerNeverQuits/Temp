import { throwError } from "rxjs";

export const handleGenericErrors = err => {
  const errorObject = err.message[0];
  const error = {
    status: errorObject.status,
    code: errorObject.code,
    detail: errorObject.detail,
    data: errorObject
  };

  console.error(error);

  return throwError(error);
};
