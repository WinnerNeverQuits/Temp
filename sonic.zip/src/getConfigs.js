import { catchError, map } from "rxjs/operators";
import { fetch } from "./fetch";
import { handleGenericErrors } from "./handleGenericErrors";

const configs = new Map([]);

export const _getConfigs = alias =>
  fetch(`/cms/configs/${alias}?include=default`).pipe(
    map(res => res),
    catchError(handleGenericErrors)
  );

export const getConfigs = alias => {
  if (configs.has(alias)) {
    return configs.get(alias);
  }

  const config = _getConfigs(alias);
  configs.set(alias, config);
  return config;
};
