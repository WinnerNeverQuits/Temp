import { catchError, map } from "rxjs/operators";
import { fetch } from "./fetch";
import { handleGenericErrors } from "./handleGenericErrors";

const userShape = {
  attributes: {
    anonymous: true,
    authProviders: [],
    bucket: "",
    country: "",
    currentLocationTerritory: "",
    currentlyLocatedInEU: false,
    emailValidationStatus: "",
    features: [],
    firstName: "",
    lastLoginTime: "",
    lastName: "",
    newsletterPreference: "",
    packages: [],
    products: [],
    realm: "",
    selectedAuthProvider: "",
    selectedProfileId: "",
    username: ""
  },
  id: "",
  type: ""
};

export const getCurrentUser = () =>
  fetch("/users/me").pipe(
    map(res => {
      const user = res.data;

      if (user) {
        // User same user shape for logged-in and -out users to support
        // performance gains of retaining object shapes
        return { ...userShape, ...user };
      }
    }),
    catchError(handleGenericErrors)
  );
