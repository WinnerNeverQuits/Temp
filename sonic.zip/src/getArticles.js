import { catchError, map } from "rxjs/operators";
import { fetch } from "./fetch";
import { handleGenericErrors } from "./handleGenericErrors";

export const getArticles = article =>
  fetch(`/cms/articles/${article}?include=default`).pipe(
    map(res => res),
    catchError(handleGenericErrors)
  );
