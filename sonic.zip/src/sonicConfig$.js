import { BehaviorSubject } from "rxjs";

export const sonicConfig$ = new BehaviorSubject({
  baseURI: "",
  token: "",
  clientName: "",
  clientVersion: ""
});

export const sonicConfig = config => {
  sonicConfig$.next(config);
};
