import { login } from "./login";


describe('login test', () => {
  beforeEach(() => {
    fetch.resetMocks();
  });

  it('login url is hit once', () => {
    fetch.mockResponseOnce();
    
    login('username', 'password').subscribe();

    //assert on the arguments given to fetch
    expect(fetch.mock.calls[0][0]).toEqual('/login');

    //assert on the times called
    expect(fetch.mock.calls.length).toEqual(1);
  });
  
})

