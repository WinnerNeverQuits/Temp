import Cookie from "js-cookie";
import { of } from "rxjs";
import { flatMap, map, tap } from "rxjs/operators";
import { fetch } from "./fetch";
import { sonicConfig } from "./sonicConfig$";

export const bootstrap = ({
  realmService: {
    uri = "https://global-prod.disco-api.com/realms",
    brand,
    countryCode = false,
    recommended = false
  },
  cookieName = "token",
  clientName,
  clientVersion
}) => {
  let url = `${uri}?filter[brand]=${brand}`;

  if (countryCode) {
    url += `&hintIosStoreKitProductLocaleRegionCode=${countryCode}`;
  }

  if (recommended) {
    url += `&filter[recommended]=true`;
  }

  return fetch(url, false).pipe(
    map(d => {
      if (d.data && d.data[0]) {
        return {
          realm: d.data[0].id,
          baseURI: d.data[0].attributes.sonicBaseUrl
        };
      }
      throw new Error("No Realm Available");
    }),
    flatMap(({ realm, baseURI }) => {
      const token = Cookie.get(cookieName);
      const tokenRealm = `${baseURI}|${realm}|${brand}`;

      if (token && Cookie.get(`${cookieName}Realm`) === tokenRealm) {
        return of({
          baseURI,
          token: token,
          clientName,
          clientVersion
        });
      }
      return fetch(`${baseURI}/token?realm=${realm}`, false).pipe(
        map(d => {
          const token = d.data.attributes.token;
          Cookie.set(cookieName, token);
          Cookie.set(`${cookieName}Realm`, tokenRealm);

          return {
            baseURI,
            token,
            clientName,
            clientVersion
          };
        })
      );
    }),
    tap(sonicConfig)
  );
};
