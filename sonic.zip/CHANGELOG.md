# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.3.0](https://github.com/DNI-Mercury/cd-tv-core/compare/v0.2.0...v0.3.0) (2019-07-11)


### Bug Fixes

* **packages/sonic/src:** encode values only instead of encode false ([dbe6ccf](https://github.com/DNI-Mercury/cd-tv-core/commit/dbe6ccf))
* **platform, navigation:** fixes native keyboard support (working on Fire TV, Samsung) ([06a4e0e](https://github.com/DNI-Mercury/cd-tv-core/commit/06a4e0e))
* **sonic/get-articles:** add missing imports ([2914c19](https://github.com/DNI-Mercury/cd-tv-core/commit/2914c19))


### Features

* **sonic:** add the getMediaInfo and getPlaybackInfo endpoints ([eed7050](https://github.com/DNI-Mercury/cd-tv-core/commit/eed7050))





# [0.2.0](https://github.com/DNI-Mercury/cd-tv-core/compare/v0.1.2...v0.2.0) (2019-06-27)


### Bug Fixes

* **fetch:** check if API returns json to handle errors ([43feaa4](https://github.com/DNI-Mercury/cd-tv-core/commit/43feaa4))
* **sonic:** add missing imports ([6393295](https://github.com/DNI-Mercury/cd-tv-core/commit/6393295))
* **sonic:** add missing imports for getCollections and getConfigs ([b981962](https://github.com/DNI-Mercury/cd-tv-core/commit/b981962))
* **sonic:** add qs params to getCollections ([bb39421](https://github.com/DNI-Mercury/cd-tv-core/commit/bb39421))
* **sonic:** remove duplicate line ([a5c96b6](https://github.com/DNI-Mercury/cd-tv-core/commit/a5c96b6))


### Features

* **sonic:** adds client name and version to sonic config ([e9d2b68](https://github.com/DNI-Mercury/cd-tv-core/commit/e9d2b68))
* **sonic:** adds x-disco-client header to all API requests ([55a4eef](https://github.com/DNI-Mercury/cd-tv-core/commit/55a4eef))





## [0.1.2](https://github.com/DNI-Mercury/cd-tv-core/compare/v0.1.1...v0.1.2) (2019-06-17)

**Note:** Version bump only for package @discovery-dni/cd-tv.sonic





## [0.1.1](https://github.com/DNI-Mercury/cd-tv-core/compare/v0.1.0...v0.1.1) (2019-06-17)

**Note:** Version bump only for package @discovery-dni/cd-tv.sonic





# [0.1.0](https://github.com/DNI-Mercury/cd-tv-core/compare/v0.0.1...v0.1.0) (2019-06-16)

**Note:** Version bump only for package @discovery-dni/cd-tv.sonic
