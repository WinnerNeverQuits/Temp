export const keys = {
  'OPEN_EDITOR': 'OPEN_EDITOR',
  'CLOSE_EDITOR': 'CLOSE_EDITOR',
}

export const openEditor = (movieId) => {
  return {
    type: keys.OPEN_EDITOR,
    movieId
  };
}

export const closeEditor = () => {
  return {
    type: keys.CLOSE_EDITOR
  };
}
