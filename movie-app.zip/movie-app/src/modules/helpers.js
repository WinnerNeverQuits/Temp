
export const getGenresList = (moviesResponse) => {
  return moviesResponse;
}

export const getMoviesList = (moviesResponse) => {
  return !!moviesResponse ? ([
    ...moviesResponse.results
  ]) : null;
}