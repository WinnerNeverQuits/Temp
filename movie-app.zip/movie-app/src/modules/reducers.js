import {combineReducers} from 'redux';
import { createReducer, createAsyncReducer } from './common/redux.helpers';
import { keys as movieActionKeys } from './actions';
import movieModalReducer from './editor/reducer';


const moviesSuccessReducer = (state, action) => {
  const existingMovies = state.response ? state.response.results : [];

  return {
    ...state,
    isLoading: false,
    response: {
      ...action.response,
      results: [
        ...existingMovies,
        ...action.response.results
      ]
    }
  };
}

const movieBrowserReducer = combineReducers({
  movieModal: movieModalReducer,
  genres: createAsyncReducer(movieActionKeys.GET_GENERES),
  moviesResults: createAsyncReducer(movieActionKeys.SEARCH_MOVIES),  
  movieDetails: createAsyncReducer(movieActionKeys.GET_MOVIE_DETAILS),
});

export default movieBrowserReducer;
