import {createAsyncActionCreator} from './common/redux.helpers';
import * as dataService from './data.service';

export const keys = {
  'GET_GENERES': 'GET_GENERES',
  'SEARCH_MOVIES': 'SEARCH_MOVIES',
  'GET_MOVIE_DETAILS': 'GET_MOVIE_DETAILS',
};

export const getGenres = () => createAsyncActionCreator(keys.GET_GENERES, dataService.getGenres);

export const searchMovies = (genre) => createAsyncActionCreator(keys.SEARCH_MOVIES,dataService.searchMovies, {genre});

export const getMovieDetails = (movieId) => createAsyncActionCreator(
  keys.GET_MOVIE_DETAILS,
  dataService.getMovieDetails, 
  {movieId}
);
