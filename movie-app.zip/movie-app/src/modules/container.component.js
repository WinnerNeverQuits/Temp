import React from "react";
import { connect } from "react-redux";
import { Grid, Row, Col } from "react-bootstrap";
import { AppBar, TextField, RaisedButton, Toolbar } from "material-ui";

import * as movieActions from "./actions";
import * as movieHelpers from "./helpers";
import MovieList from "./list.component";
import Editor from "./editor/container.component";


class ContainerComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.handleSearch = this.handleSearch.bind(this);
  }

  
  handleSearch(event) {
    this.props.searchMovies(event.target.value);
  }

  componentDidMount() {
    this.props.getGenres();
  }

  render() {
    const { genres, moviesResults } = this.props;
    const movies = movieHelpers.getMoviesList(moviesResults.response);
    const genresList = movieHelpers.getGenresList(genres.response);
    const options = genresList
    ? genresList.map(genre => (
      <option key={genre}>{genre}</option>
      ))
      : null;
    
   
    return (
      <div>
        <AppBar style={{ background: '#DC143C' }} title="My Movies">
       
        </AppBar>
        <Grid>
          <Row>
            <label>
              Genre:
              <select onChange={this.handleSearch}>
              {options}
              </select>
            </label>
          </Row>         
          <Row>
            <MovieList movies={movies} isLoading={moviesResults.isLoading} />
          </Row>
        </Grid>
        <Editor />
      </div>
    );
  }
}

export default connect(
  // Map nodes in our state to a properties of our component
  state => ({
    genres: state.movieBrowser.genres,
    moviesResults: state.movieBrowser.moviesResults
  }),
  // Map action creators to properties of our component
  { ...movieActions }
)(ContainerComponent);
