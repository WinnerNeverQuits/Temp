export const getGenres = async () => {  
  return fetch('mock-db/genres/genres.json'); 
}

export const searchMovies = async (genre) => {  
  return fetch(`mock-db/genres/${genre.genre}.json`); 
}

export const getMovieDetails = async ({ movieId }) => {  
  return fetch(`mock-db/movies/${movieId}/${movieId}.json`);   
}
