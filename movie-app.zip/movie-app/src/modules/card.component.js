import React from 'react';
import {connect} from 'react-redux';
import {Card, CardTitle, CardMedia} from 'material-ui';
import {openEditor} from './editor/actions';

const styles = {
  cardMedia: {
    maxHeight: 394,
    overflow: 'hidden'
  },
  card: {
    cursor: 'pointer',
    height: 400,
    overflow: 'hidden'
  },
  bgImage: {
    width: '100%'
  }
};

class CardComponent extends React.Component {
  constructor(props) {
    super(props);
   
    this.state = {
      isMouseOver: false
    };
  }
  
  render() {
    const {movie, openEditor} = this.props;    
    const subtitle = this.state.isMouseOver ? movie.overview : null;

    return (
    
      <Card
        style={styles.card}
        onMouseOver={() => this.setState({isMouseOver: true})}
        onMouseLeave={() => this.setState({isMouseOver: false})}
        onClick= {() => openEditor(movie.id)}
      >
        <CardMedia
          style={styles.cardMedia}
          overlay={
            <CardTitle
              title={movie.title} 
              subtitle={subtitle} 
            />
          }
        >          
          <img style={styles.bgImage} src={`mock-db/movies/${movie.id}/${movie.id}.card.jpg`} />
        </CardMedia>
      </Card>
    );
  }
}

export default connect(
  () => ({}),
  { openEditor: openEditor }
)(CardComponent);
