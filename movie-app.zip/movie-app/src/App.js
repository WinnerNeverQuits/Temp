import React, { Component } from 'react';
import ContainerComponent from './modules/container.component';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider'

class App extends Component {
  render() {
    return (     
      <MuiThemeProvider>
        <ContainerComponent />
      </MuiThemeProvider>
    );
  }
}

export default App;
